ссылка на сайт: https://test-tickets.netlify.app/
command:
1. dev
2. build
3. lint
4. preview
